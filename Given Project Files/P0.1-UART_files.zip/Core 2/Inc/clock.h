/*
 * clock.h
 *
 *  Created on: Jul 16, 2021
 *      Author: rickweil
 */

#ifndef INC_CLOCK_H_
#define INC_CLOCK_H_

void clock_init(void);

#endif /* INC_CLOCK_H_ */
