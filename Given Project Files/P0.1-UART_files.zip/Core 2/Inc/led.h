/*
 * led.h
 *
 *  Created on: Jul 16, 2021
 *      Author: rickweil
 */

#ifndef INC_LED_H_
#define INC_LED_H_


void led_init(void);
void led_set(_Bool on_off );
_Bool led_isOn(void );

#endif /* INC_LED_H_ */
