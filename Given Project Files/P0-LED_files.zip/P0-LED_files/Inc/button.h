/*
 * button.h
 *
 *  Created on: Jul 16, 2021
 *      Author: rickweil
 */

#ifndef INC_BUTTON_H_
#define INC_BUTTON_H_


void button_init(void);
_Bool button_isPressed(void);

#endif /* INC_BUTTON_H_ */
